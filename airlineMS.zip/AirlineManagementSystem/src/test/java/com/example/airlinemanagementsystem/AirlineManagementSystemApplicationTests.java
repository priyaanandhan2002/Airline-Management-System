package com.example.airlinemanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlineManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
